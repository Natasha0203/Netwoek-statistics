# Network Statistics for a Minimum Spanning Tree
The code to extract the centralities and basics statistics measures from  a MST, 
 tables it and save as a .csv file.
